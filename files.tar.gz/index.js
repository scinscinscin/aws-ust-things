const { Client } = require("pg");
const express = require("express");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const mime = require("mime-types");
const fsp = require("fs/promises");
const path = require("path");
const cors = require("cors");
const app = express();
require("dotenv").config();

app.use(express.json());
app.use(cors({ origin: "http://localhost:5173", credentials: true }));

function get_env_var(candidate) {
  if (typeof candidate === "string" && candidate.length > 0) return candidate;
  else return null;
}

const PORT = process.env.API_PORT || 8080;
const DATABASE_URL = get_env_var(process.env.DATABASE_URL);
const S3_BUCKET_NAME = get_env_var(process.env.S3_BUCKET_NAME);
const AWS_REGION = get_env_var(process.env.AWS_REGION);

function cleanse_user(user) {
  const image_url = user.image_id.startsWith("production-")
    ? `https://${S3_BUCKET_NAME}.s3.${AWS_REGION}.amazonaws.com/${user.image_id}`
    : `http://localhost:${PORT}/uploads/${user.image_id}`;

  return {
    id: user.id,
    username: user.username,
    image_url: image_url,
  };
}

async function create_mock_db() {
  console.log("🔴 No RDS Connection string found, using mock database");
  let users = [];

  async function create_user(username, image_id) {
    const id = users.length + 1;
    const user = { id, username, image_id };
    users.push(user);
    return cleanse_user(user);
  }

  async function get_users() {
    return users.map(cleanse_user);
  }

  async function reset() {
    users = [];
  }

  return { create_user, get_users, reset };
}

async function create_real_db() {
  console.log("✅ RDS Connection string found, using real database");
  console.log("🚀 Connecting to database: " + DATABASE_URL);

  async function create_tables_if_not_exists(client) {
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        image_id TEXT NOT NULL
      );
    `);
  }

  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();
  await create_tables_if_not_exists(client);

  async function create_user(username, image_id) {
    const res = await client.query("INSERT INTO users (username, image_id) VALUES ($1, $2) RETURNING *", [
      username,
      image_id,
    ]);

    return cleanse_user(res.rows[0]);
  }

  async function get_users() {
    const res = await client.query("SELECT * FROM users");
    return res.rows.map(cleanse_user);
  }

  async function reset() {
    await client.query("DELETE FROM users");
  }

  return { create_user, get_users, reset };
}

const STATIC_FOLDER = path.join(process.cwd(), "local_uploads");
const PUBLIC_FOLDER = path.join(process.cwd(), "public");

async function create_mock_s3(app) {
  console.log("🔴 No S3 bucket name found, using mock S3");
  console.log("Attaching fake S3 API to the application");

  app.put("/api/uploads/:key", express.raw({ type: "*/*", limit: "10mb" }), async (req, res) => {
    const key = req.params.key;
    const filePath = path.join(STATIC_FOLDER, key);
    await fsp.writeFile(filePath, req.body);
    res.status(200).send("ok");
  });

  async function create_presigned_url(contentType) {
    const extension = mime.extension(contentType);
    const key = `development-${crypto.randomUUID()}.${extension}`;
    return { upload_url: `/api/uploads/${key}`, key };
  }

  return { create_presigned_url };
}

async function create_real_s3() {
  console.log("✅ S3 bucket name found, using real S3");
  console.log("🚀 Connecting to S3");

  const client = new S3Client({ region: AWS_REGION });

  async function create_presigned_url(contentType) {
    const extension = mime.extension(contentType);
    const key = `production-${crypto.randomUUID()}.${extension}`;

    const command = new PutObjectCommand({
      Bucket: S3_BUCKET_NAME,
      ContentType: contentType,
      Key: key,
    });

    const upload_url = await getSignedUrl(client, command, { expiresIn: 60 });
    return { upload_url, key };
  }

  return { create_presigned_url };
}

async function main() {
  // on startup, check the configuration that we have and determine how to setup the application
  const db = DATABASE_URL != null ? await create_real_db() : await create_mock_db();
  const s3 = S3_BUCKET_NAME != null ? await create_real_s3() : await create_mock_s3(app);

  // setup local storage backend
  // create ./uploads folder if it doesn't exist
  console.log("Creating local storage backend at " + STATIC_FOLDER);
  await fsp.mkdir(STATIC_FOLDER, { recursive: true });

  app.post("/api/uploads/presigned", async (req, res) => {
    const { contentType } = req.body;
    s3.create_presigned_url(contentType)
      .then((presigned_url) => res.json(presigned_url))
      .catch((err) => res.status(500).send(err));
  });

  app.get("/api/users", async (req, res) => {
    db.get_users()
      .then((users) => res.json(users))
      .catch((err) => res.status(500).send(err));
  });

  app.post("/api/users", async (req, res) => {
    const { username, image_id } = req.body;
    db.create_user(username, image_id)
      .then((user) => res.json(user))
      .catch((err) => res.status(500).send(err));
  });

  app.get("/api/metadata", (req, res) => {
    res.json({
      rds: DATABASE_URL != null,
      s3: S3_BUCKET_NAME != null,
    });
  });

  app.use("/uploads", express.static(STATIC_FOLDER));
  app.use("/", express.static(PUBLIC_FOLDER));

  app.listen(PORT, () => {
    console.log("Application is being served on port " + PORT);
  });
}

main().catch((err) => {
  console.log("Failed to setup the API");
  console.log(err);
  process.exit(-1);
});
